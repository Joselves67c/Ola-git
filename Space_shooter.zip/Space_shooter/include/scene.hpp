#pragma once

#include <SFML/Graphics.hpp>

class SceneManager;

class Scene
{
  public:
	virtual void init() = 0;
	
	virtual void events(sf::Event &) = 0;

	virtual void update(const float &) = 0;

	virtual void render(sf::RenderWindow &) = 0;

	virtual ~Scene() = default;

	SceneManager *m_scenes;
};
