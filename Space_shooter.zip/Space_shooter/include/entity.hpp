#pragma once

#include "component.hpp"
#include <unordered_map>
#include <typeindex>
#include "ecs_observer_pattern.hpp"

namespace Ecs
{
class World;

class Entity : public Server
{
  public:
	Entity(World *w);

	//construtor de copia deletado
	Entity(const Entity &) = delete;

	//construtor de movimento deletado
	Entity(Entity &&) noexcept = delete;

	//operador de atribuicao deletado
	Entity &operator=(const Entity &) = delete;

	//operador de atribuicao de movimento deletado
	Entity operator=(Entity &&) noexcept = delete;

	//adiciona um componente a entidade
	template <typename C>
	C *addComponent();

	//retorna um componente na entidade
	template <typename C>
	C *getComponent();

	//destroi um componente na entidade
	template <typename C>
	void destroyComponent();

	//destroi essa entidade no mundo que pertence
	void destroy(); //sera implementado no arquivo "world.hpp"

	//verdadeiro se o componente existir false caso contrario
	template <typename C>
	bool hasComponent();

  protected:
	//lista que vai armazenar todas os componentes na entidade
	std::unordered_map<std::type_index, std::unique_ptr<Component>> components;

	//World é o mundo onde a entidade vai existir
	World *world;
};

//adiciona um componente a entidade
template <typename C>
C *Entity::addComponent()
{
	//aloque uma nova memoria para um novo componente
	auto component = std::make_unique<C>();

	//ponteiro que vai quardar a memoria a ser retornada
	C *res_ptr = component.get();

	//adiociona o componente a lista
	this->components.insert(std::make_pair<std::type_index, std::unique_ptr<Component>>(typeid(C), std::move(component)));

	//notifique a todos os sistemas que um novo componente foi adicionado
	for (auto &client : clientes)
	{
		if (client)
		{
			client->notify(Info::addedComponent,this);
		}
		else
		{
			throw std::runtime_error("ERRO DE PONTEIRO NO ECS NA AO ADICIONAR UM COMPONENTE");
		}
	}

	//retorne o ponteiro
	return res_ptr;
}

//retorna um componente na entidade
template <typename C>
C *Entity::getComponent()
{
	//procure o componente na lista
	auto it = this->components.find(typeid(C));

	//se achou retorne o componente e sia da funçao
	if (it != this->components.cend())
	{
		return static_cast<C *>(it->second.get());
	}

	//se o componente nao foi achado retorne ponteiro nulo
	return nullptr;
}

//destroi um componente na entidade
template <typename C>
void Entity::destroyComponent()
{
	//procure o componente na lista
	auto it = this->components.find(typeid(C));

	//se achou remova o componente da lista
	if (it != this->components.cend())
	{
			//remova o componete
		this->components.erase(it);
		
				//notifique a todos os sistemas que um novo componente foi removido
		for (auto &client : clientes)
		{
			if (client)
			{
				client->notify(Info::removedComponent,this);
			}
			else
			{
				throw std::runtime_error("ERRO DE PONTEIRO NO ECS NA AO REMOVER UM COMPONENTE");
			}
		}
	
	}

	//fim da funcao
}

//verdadeiro se o componente existir false caso contrario
template <typename C>
bool Entity::hasComponent()
{
	//procure o componente na lista
	auto it = this->components.find(typeid(C));

	//se achou retorne verdadeiro
	if (it != this->components.cend())
	{
		return true;
	}

	//caso contrario retorne falso

	return false;
}
} // namespace Ecs