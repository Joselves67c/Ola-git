#pragma once

#include <string>
#include <unordered_map>

template <class N, class T>
class Resources
{
  public:
	void load(const N &name, const std::string &f);

	T &get(const N &name) const;

  private:
	std::unordered_map<N,std::unique_ptr<T>> m_resources;
};

template <class N, class T>
void Resources<N, T>::load(const N &name, const std::string &f)
{
  auto res=std::make_unique<T>();
  
  if(!res->loadFromFile(f))
  {
  	throw std::runtime_error(std::string("ERRO AO CARREGAR O RECUROS ")+std::string(f));
  }
  
  this->m_resources.insert({name,std::move(res)});
}

template <class N, class T>
T &Resources<N, T>::get(const N &name) const
{
	return *(this->m_resources.at(name));
}