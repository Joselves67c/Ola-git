#pragma once
#include <memory>
#include <deque>

namespace Ecs
{
//uma entidade do jogo
class Entity;

//informaçoes da notificaçao
enum class Info
{
	addedEntity,
	removedEntity,
	addedComponent,
	removedComponent
};

//no ecs os clientes sao os sistemas
class Client
{
  public:
	virtual void notify(const Info &, Entity*) = 0;
	virtual ~Client() = default;
};

//servidores sao o mundo e as entidades
class Server
{
  public:
	std::deque<Client *> clientes;
};

} // namespace Ecs