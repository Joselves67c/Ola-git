#pragma once
 
#include "vector2.hpp"
#include <SFML/Graphics.hpp>

float convert(float dx,float setx,float v);


class WVector2 : public Math::Vector2
{
	public:
	 WVector2(const float& fx=0,const float& fy=0);
	 
	 WVector2 toWorldScreen()const;
	 
	 static WVector2 toWorldScreen(const float& ,const float& );
	 
	 sf::Vector2f getSfmlVector()const;
	 
	 static WVector2 descktopW;
	 static WVector2 fixedWindow;
};

