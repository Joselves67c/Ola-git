#pragma once

#include "button.hpp"
#include "scenes_manager.hpp"
#include "engine_systems.hpp"
#include "resurce.hpp"
#include <SFML/Audio.hpp>

class Level1 : public Scene
{
  public:
	void init() override;

	void events(sf::Event &) override;

	void update(const float &) override;

	void render(sf::RenderWindow &) override;
	
	Button pause;
	sf::Sprite pause_icon;
	
	Ecs::World world;
};
class MainMenu : public Scene
{
  public:
	void init() override;

	void events(sf::Event &) override;

	void update(const float &) override;

	void render(sf::RenderWindow &) override;

	std::vector<Button> buttons;
	 Resources<std::string,sf::Texture> m_textures;
	 Resources<std::string,sf::SoundBuffer> m_sounds;
	 sf::Sprite menu_sprite;
	 sf::Music music;
	 sf::RenderWindow* window;
};