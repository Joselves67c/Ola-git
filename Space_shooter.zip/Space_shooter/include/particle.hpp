#pragma once

#include "vector2.hpp"

class Particle
{
  public:
	Particle();

	void update(const float &dt);

	void setPosition(const float &x, const float &y);

	const Math::Vector2 &getPosition() const;

	void setVelocity(const float &x, const float &y);

	const Math::Vector2 &getVelocity() const;

	void addForce(const float &x, const float &y);

	void setLifeTime(const float &);

	const float &getLifeTime() const;

	void setSize(const float &);

	const float &getSize() const;

	void setAngularVelocity(const float &);

	const float &getAngularVelocity() const;

	void setOrientation(const float &o);

	const float &getOrientation() const;

	void setSizeVelocity(const float &sv);

	const float &getSizeVelocity() const;

  protected:
	Math::Vector2 position;
	Math::Vector2 velocity;
	Math::Vector2 force;
	float orientation;
	float angular_velocity;
	float size;
	float sizeVelocity;
	float life_time;
};