#pragma once

#include "precision.hpp"
#include <iostream>

namespace Math
{

struct Vector2
{
	//construtor da classe Vector
	Vector2(const Real& _x=0,const Real& _y=0);
	
	//funcao que realiza adicao de vetores
	Vector2 operator+(const Vector2& v)const;
	
	//
	void operator+=(const Vector2& v);
	
	//funcao que realiza subtracao de vetores
	Vector2 operator-(const Vector2& v)const;
	
	//
	void operator-=(const Vector2& v);
	
	//funcao que multiplica o vetor um escalar
	Vector2 operator*(const Real& s)const;
	
	//
	void operator*=(const Real& s);
	
	//funçao que realiza o produto escalar
	Real operator*(const Vector2& v)const;
	
	//funcao que retorna o tamanho do vetor
	Real magnitude()const;
	
	//funçao que retorna esse vetor como unitario
	Vector2 getUnity()const;
	
	//normaliza este vetor
	void normalize();
	
	//retorna um vetor perpendicular
	Vector2 getPerpendicular()const;
	
	//inverte este vetor
	void invert();
	
	Real x,y;
};

std::ostream& operator<<(std::ostream& out,const Math::Vector2& v);
} // namespace Math