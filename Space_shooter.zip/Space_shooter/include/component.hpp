#pragma once

namespace Ecs
{
	//classe base para todos os componentes
	struct Component
	{
		//declaraçao do destrutor virtual padrao
		virtual ~Component();
	};
	
}