#pragma once

#include "ecs_system.hpp"
#include <list>

namespace Ecs
{
	//o mundo em que as entidades e sistemas enxistem
class World : public Server
{
  public:
	//adiciona uma entidade ao mundo
	Entity *addEntity();

	//destroi uma entidade no mundo
	void destroyEntity(const Entity *const);

	//adiciona um sistema ao mumdo
	template <typename S>
	S *addSystem();

	//retorna um sistema no mundo
	template <typename S>
	S *getSystem();

	//chamado uma unica vez
	void init();

	//chamado a cada frame
	void update(const float &dt);

  protected:
	std::list<std::unique_ptr<Entity>> entitys;
	std::unordered_map<std::type_index, std::unique_ptr<BaseSystem>> systems;
};

//adiciona um sistema ao mumdo
template <typename S>
S *World::addSystem()
{
	auto system = std::make_unique<S>();

	S *p_system = system.get();
	system->world = this;
	this->clientes.push_back(system.get());

	this->systems.insert(std::make_pair<std::type_index, std::unique_ptr<BaseSystem>>(typeid(S), std::move(system)));

	return p_system;
}

//retorna um sistema no mundo
template <typename S>
S *World::getSystem()
{
	auto it=this->systems.find(typeid(S));
	
	if(it!=this->systems.cend())
	{
		return static_cast<S*>(it->second.get());
	}
	return nullptr;
	
}
} // namespace Ecs