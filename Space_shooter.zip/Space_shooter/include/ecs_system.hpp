#pragma once
#include "entity.hpp"
#include <list>

namespace Ecs
{
namespace NSystem
{
//funcao personalizado para a nao deletar o objeto contido no shared_ptr<Entity>
void deleter(Ecs::Entity *entity);
}
//classe que verifa se a entidade possui os componentes necessarios para ser aceito pelo sistem
class CheckAllComponents
{
  public:
	Entity *entity;
	template <typename T>
	bool hasComponents(T t)
	{
		return entity->hasComponent<T>();
	}

	template <typename C, typename... T>
	bool hasComponents(C c, T... t)
	{
		return entity->hasComponent<C>() && hasComponents(t...);
	}
};

//class base Para todos os sistemas
class BaseSystem : public Client
{
	friend class World;

  public:
   //chamado ao iniciar um mundo
	virtual void init() = 0;
  //chamado a cada frame
	virtual void update(const float &) = 0;

	virtual ~BaseSystem() = default;

  protected:
	World *world;//o mundo em que este sistem enxiste
};
template <class... T>
class System : public BaseSystem
{
  public:
  //verifica se uma determinada entidade enxiste verdadeiro se enxistir falso caso contrario
	bool hasEntity(const Entity *const entity) const;
	
	//retorna as entidades que estao no sistema
	std::deque<std::weak_ptr<Entity>> getEntitys();

  protected:
  //chamado quando o sistema aceita a entidade para ser inserida
	virtual void addedEntity(Entity *);

//chamado quando o sistem aceita a entidade para ser removida
	virtual void removedEntity(Entity *);

//chamado quando a entidade atende aos componentes que o sistema necessita
	virtual void addedComponent(Entity *);
	
//chamado quando a entidade nao posui componentes que o sistema necessita
	virtual void removedComponent(Entity *);
	
	
    
  private:
  //destroi uma entidade se enxistir caso contrario nao faz nada
    void destroy(const Entity* const e);
    
	void checkAddedEntity(Entity *);//

	void checkRemovedEntity(Entity *);///

	void checkAddedComponent(Entity *);//

	void checkRemovedComponent(Entity *);//

	void notify(const Info &, Entity *) final;//

	std::list<std::shared_ptr<Entity>> entitys;
};

template <class... T>
void System<T...>::addedEntity(Entity *e)
{
	std::shared_ptr<Entity> entity(e,NSystem::deleter);
	this->entitys.push_back(entity);
}
template <class... T>
void System<T...>::removedEntity(Entity *e)
{
	this->destroy(e);
}
template <class... T>
void System<T...>::addedComponent(Entity *e)
{
	std::shared_ptr<Entity> entity(e,NSystem::deleter);
	this->entitys.push_back(entity);
}
template <class... T>
void System<T...>::removedComponent(Entity *e)
{
	this->destroy(e);
}

///
template <class... T>
void System<T...>::checkAddedEntity(Entity *e)
{
	CheckAllComponents check;
	check.entity = e;

	if (check.hasComponents((T())...))
	{
		if (!this->hasEntity(e))
		{
			this->addedEntity(e);
		}
	}
}
template <class... T>
void System<T...>::checkRemovedEntity(Entity *e)
{
	this->removedEntity(e);
}

template <class... T>
void System<T...>::checkAddedComponent(Entity *e)
{
	CheckAllComponents check;
	check.entity = e;

	if (check.hasComponents((T())...))
	{
		if (!this->hasEntity(e))
		{
			this->addedComponent(e);
		}
	}
}
template <class... T>
void System<T...>::checkRemovedComponent(Entity *e)
{
	CheckAllComponents check;
	check.entity = e;

	if (!check.hasComponents((T())...))
	{
		this->removedComponent(e);
	}
}

///
template <class... T>
void System<T...>::notify(const Info &info, Entity *entity)
{
	switch (info)
	{
	case Info::addedEntity:
		this->checkAddedEntity(entity);
		break;

	case Info::removedEntity:
		this->checkRemovedEntity(entity);
		break;

	case Info::addedComponent:
		this->checkAddedComponent(entity);
		break;

	case Info::removedComponent:
		this->checkRemovedComponent(entity);
		break;
	}
}

template <class... T>
bool System<T...>::hasEntity(const Entity *const entity) const
{
	auto it = std::find_if(this->entitys.begin(),this-> entitys.end(), [&](std::shared_ptr<Entity> e) {
		if (e.get() == entity)
		{
			return true;
		}

		return false;
	});

	if (it != entitys.cend())
	{
		return true;
	}
	return false;
}
template<typename ...T>
void System<T...>::destroy(const Entity* const entity)
{
	auto it = std::find_if(entitys.begin(), entitys.end(), [&](std::shared_ptr<Entity> e) {
		if (e.get() == entity)
		{
			return true;
		}

		return false;
	});

	if (it != entitys.cend())
	{
		this->entitys.erase(it);
	}
}
template<typename ...T>
std::deque<std::weak_ptr<Entity>> System<T...>::getEntitys()
{
	std::deque<std::weak_ptr<Entity>> _entitys;
	
	for(auto& entity:this->entitys)
	{
		_entitys.push_back(entity);
	}
	return _entitys;
}
} // namespace Ecs