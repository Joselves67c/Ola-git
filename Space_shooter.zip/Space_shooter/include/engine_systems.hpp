#pragma once

#include "components.hpp"

class RenderSystem : public Ecs::System<PositionComponent, LayerComponent>
{
	void init() override;

	void update(const float &dt) override;

  public:
	void draw(sf::RenderWindow &);
};

class MovementSystem : public Ecs::System<PositionComponent, VelocityComponent>
{
	void init() override;

	void update(const float &dt) override;
};

class CollisionSystem : public Ecs::System<AABBComponent,PositionComponent>
{
	void init() override;

	void update(const float &dt) override;
};