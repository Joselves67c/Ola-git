#pragma once

#include "world.hpp"
#include <SFML/Audio.hpp>

enum class BulletType
{
	Player = 0,
	Enemy
};
class Player : public Ecs::Component
{
  public:
};

class DamageComponent : public Ecs::Component
{
  public:
	int damage;
};

class BulletTypeComponent : public Ecs::Component
{
  public:
	BulletType bullet_type;
};

class AiDecisonComponent : public Ecs::Component
{
  public:
	float elapsedTime = 0;
	float time;
	int atack_probability; //probalidade dos numerios aleatorios sortearem o numero 0
};

class EnemyComponent : public Ecs::Component
{
  public:
};

class HealthComponent : public Ecs::Component
{
  public:
	int health;
};

//
struct Selection
{
	bool isSelected = false;
	bool item;
};
class SelectionComponent : public Ecs::Component
{
  public:
	Selection selected;
};

enum class ItemType
{
	Health,
	Emmo
};

class ItemTypeComponent : public Ecs::Component
{
  public:
	ItemType item_type;
};

class SoundComponent : public Ecs::Component
{
  public:
	sf::Sound sound;
};

enum class ResurceType
{
	Sound,
	Animation,
	BackGround
};

class ResurceTypeComponent : public Ecs::Component
{
  public:
	ResurceType type;
};

class DefeseComponent : public Ecs::Component
{
  public:
	float time = 0; // tempo para a defesa da nave acabar
};

enum class TextType
{
	Health=1,
	Round
};

class TextTypeComponent : public Ecs::Component
{
  public:
    TextType type;
};