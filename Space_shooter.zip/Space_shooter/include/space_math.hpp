#pragma once

extern float clamp(const float& var,const float& min,const float& max);