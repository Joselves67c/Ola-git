#pragma once

#include <SFML/Graphics.hpp>

class Button
{
  public:
	Button();

	void setPosition(const sf::Vector2f &);

	void setColor(const sf::Color &);

	void setSize(const sf::Vector2f &);

	void setShowRectangle(const bool &);

	void event(sf::Event &);

	void draw(sf::RenderWindow &);

	void setCall(std::function<void()>);

  protected:
	bool m_render;
	sf::FloatRect m_boundbox;
	sf::RectangleShape m_rectangle;
	std::function<void()> m_callable;
};