#pragma once

#include <SFML/Graphics.hpp>
#include <vector>

class Animation
{
  public:
	Animation(sf::Texture &texture, int frameWidth, int frameHeight, int columns, int rows, float frameDuration);

	void update(float deltaTime);

	void applyToSprite(sf::Sprite &sprite);

	const int &getCurrentFrame() const;

	std::vector<sf::IntRect> m_frames;

  private:
	sf::Texture &m_texture;
	int m_frameWidth;
	int m_frameHeight;
	int m_columns;
	int m_rows;
	float m_frameDuration;
	int m_currentFrame;
	float m_elapsedTime;
};
