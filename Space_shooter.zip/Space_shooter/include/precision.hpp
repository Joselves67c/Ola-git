#pragma once

#include <cmath>

namespace Math
{
#define real_sqrt(x) std::sqrtf(x)

typedef float Real;

}