#pragma once

#include "components.hpp"
#include "space_components.hpp"
#include "resurce.hpp"


class EnemySpawne : public Ecs::System<EnemyComponent>
{
	void init()override;
	
	void update(const float& dt)override;
	
	void newEnemys();
	
	void newEmmoPack(sf::Vector2f );
	
	void newHealtPack(sf::Vector2f );
	
	
	
	int health=1;///vida de cada inimigo do round
	
	int atack_probability=10; //probabilida de ataque a cada round
	public:
	int rounds=20;//rounds do jogo
	
	  Resources<std::string,sf::Texture> *m_textures;
	  std::unique_ptr<std::mt19937> rng;
	  
};

class AiDecisionSystem: public Ecs::System<AiDecisonComponent>
{
	void init()override;
	
	void update(const float& dt)override;
	
	float elapsedTime=0;
	
	std::unique_ptr<std::mt19937> rng;
};