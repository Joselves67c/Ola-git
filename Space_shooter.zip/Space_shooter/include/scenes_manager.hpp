#pragma once

#include "scene.hpp"
#include <unordered_map>
#include <memory>
#include <string>

class SceneManager
{
  public:
	template <typename T>
	T *addScene(const std::string &);

	template <typename T>
	T *getScene(const std::string &);

	void destroyScene(const std::string &);

	void loadScene(const std::string &);

	void events(sf::Event &);

	void update(const float &);

	void render(sf::RenderWindow &);

  protected:
	std::unordered_map<std::string, std::unique_ptr<Scene>> m_scenes;
	std::string m_currentScene;
};

template <typename T>
T *SceneManager::addScene(const std::string &name)
{
	auto scene = std::make_unique<T>();
	scene->m_scenes = this;
	scene->init();

	T *scene_ptr = scene.get();

	this->m_scenes.insert({name,std::move(scene)});

	return scene_ptr;
}

template <typename T>
T *SceneManager::getScene(const std::string &name)
{
	auto it = this->m_scenes.find(name);

	if (it != m_scenes.cend())
	{
		return static_cast<T *>(it->second.get());
	}

	return nullptr;
}
