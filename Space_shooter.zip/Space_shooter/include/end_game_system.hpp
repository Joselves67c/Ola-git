#pragma once 

#include "world.hpp"
#include "scenes_manager.hpp"

enum class Status{GameOver,Win};
class EndGameComponent: public Ecs::Component
{
	public:
	float time;
	Status status;
	
};


class EndGameSystem: public Ecs::System<EndGameComponent>
{
	void init() override;

	void update(const float &dt) override;
	
	public:
	SceneManager* m_scenes;
};