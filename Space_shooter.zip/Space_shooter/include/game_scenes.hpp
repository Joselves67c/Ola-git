#pragma once

#include "scenes_manager.hpp"
#include "resurce.hpp"
#include "wvector2.hpp"
#include "anim8.hpp"
#include <SFML/Audio.hpp>
#include "button.hpp"
#include "player_spawne.hpp"
#include "game_states.hpp"

class Pause:public Scene
{
	public:
	inline void init() override
	{
		if (!texture.loadFromFile("./assets/pause.png"))
		{
		}

		background.setTexture(texture);

		background.setScale(WVector2(1, 1).toWorldScreen().getSfmlVector());

		back.setPosition(WVector2(194,330).getSfmlVector());
		back.setSize(WVector2(173, 35).getSfmlVector());

		back.setShowRectangle(false);

		back.setCall([&]() {
			auto v_level1=m_scenes->getScene<Level1>("Level1");
			
			//faz com que a nave nao bugue 
			v_level1->world.getSystem<InputSystem>()->isTouching=false;
			m_scenes->loadScene("Level1");
		});
		
		main_menu.setPosition(WVector2(228, 443).getSfmlVector());
		main_menu.setSize(WVector2(97, 32).getSfmlVector());

		main_menu.setShowRectangle(false);

		main_menu.setCall([&]() {
			m_scenes->destroyScene("Level1");
			
			m_scenes->loadScene("MainMenu");
		});
		
	}

	inline void events(sf::Event &e) override
	{
		back.event(e);
		main_menu.event(e);
	}

	inline void update(const float &dt) override
	{
	}

	inline void render(sf::RenderWindow &window) override
	{
		window.draw(background);
		back.draw(window);
		main_menu.draw(window);
	}

	sf::Texture texture;
	sf::Sprite background;
	Button back,main_menu;
};

class GameOver : public Scene
{
  public:
	inline void init() override
	{
		if (!texture.loadFromFile("./assets/GameOver.png"))
		{
		}

		background.setTexture(texture);

		background.setScale(WVector2(1, 1).toWorldScreen().getSfmlVector());

		try_again.setPosition(WVector2(168, 410).getSfmlVector());
		try_again.setSize(WVector2(237, 60).getSfmlVector());

		try_again.setShowRectangle(false);

		try_again.setCall([&]() {
			m_scenes->destroyScene("Level1");
			m_scenes->addScene<Level1>("Level1");
			m_scenes->loadScene("Level1");
		});
	}

	inline void events(sf::Event &e) override
	{
		try_again.event(e);
	}

	inline void update(const float &dt) override
	{
	}

	inline void render(sf::RenderWindow &window) override
	{
		window.draw(background);
		try_again.draw(window);
	}

	sf::Texture texture;
	sf::Sprite background;
	Button try_again;
};

class Win : public Scene
{
  public:
	inline void init() override

	{
		if (!texture.loadFromFile("./assets/win.png"))
		{
		}

		background.setTexture(texture);

		background.setScale(WVector2(1, 1).toWorldScreen().getSfmlVector());

		main_menu.setPosition(WVector2(165, 400).getSfmlVector());
		main_menu.setSize(WVector2(255, 50).getSfmlVector());

		main_menu.setShowRectangle(false);

		main_menu.setCall([&]() {
			m_scenes->destroyScene("Level1");
			
			m_scenes->loadScene("MainMenu");
		});
	}

	inline void events(sf::Event &e) override
	{
		main_menu.event(e);
	}

	inline void update(const float &) override
	{
	}

	inline void render(sf::RenderWindow &window) override
	{
		window.draw(background);
		main_menu.draw(window);
	}

	sf::Texture texture;
	sf::Sprite background;
	Button main_menu;
};

class Intro : public Scene
{
  public:
	inline void init() override
	{
		std::string path = "./assets/";
		m_textures.load("Joselves", path + "joselves.png");

		anim_joselves = new Animation(m_textures.get("Joselves"), 500, 100, 1, 19, 0.06);

		joselves.setPosition(WVector2(50, (960 / 2) - 100).toWorldScreen().getSfmlVector());

		joselves.setScale(WVector2::toWorldScreen(1, 1).getSfmlVector());

		if (!m_soundBuffer.loadFromFile(path + "Intro.wav"))
		{
			throw std::runtime_error("erro ao carregar o son da  intro");
		}

		intro_sound.setBuffer(m_soundBuffer);
		intro_sound.play();
	}

	inline void events(sf::Event &) override
	{
	}

	inline void update(const float &dt) override
	{
		elapsedTime += dt;

		if (anim_joselves->getCurrentFrame() < anim_joselves->m_frames.size() - 1)
		{
			anim_joselves->update(dt);
			anim_joselves->applyToSprite(joselves);
		}

		//tempo restante
		auto rest_time = seconds - elapsedTime;
		if (rest_time <= 0)
		{
			m_scenes->addScene<MainMenu>("MainMenu")->window=window;
			m_scenes->loadScene("MainMenu");
		}
	}

	inline void render(sf::RenderWindow &window) override
	{
		window.draw(joselves);
	}

	inline ~Intro()
	{
		delete anim_joselves;
	}
	Resources<std::string, sf::Texture> m_textures;
	sf::Sprite joselves;
	Animation *anim_joselves;
	float elapsedTime = 0;
	float seconds = 8; //segundos para a intro passar
	sf::SoundBuffer m_soundBuffer;
	sf::Sound intro_sound; //som da intro
	sf::RenderWindow* window;
};

class Options : public Scene
{
  public:
	inline void init() override
	{
		button.setPosition(WVector2((400 / 2), (250)).getSfmlVector());
		button.setSize(WVector2(230, 30).getSfmlVector());

		button.setShowRectangle(false);

		button.setCall([&]() {
			if (music->getStatus() == sf::Music::Playing)
			{
				text1.setString("MUSICA: TOCAR");
				music->stop();
			}
			else
			{
				text1.setString("MUSICA: PAUSAR");
				music->play();
			}
		});

		button1.setPosition(WVector2((500 / 2) - 0, 350).getSfmlVector());
		button1.setSize(WVector2(120, 30).getSfmlVector());

		button1.setShowRectangle(false);

		button1.setCall([&]() {
			m_scenes->loadScene("MainMenu");
			m_scenes->destroyScene("Options");
		});

		if (!font.loadFromFile("/system/fonts/Roboto-Regular.ttf"))
		{
		}

		text1.setFont(font);
		text1.setString("MUSICA: PAUSAR");
		text1.setPosition(WVector2(400 / 2, 250).toWorldScreen().getSfmlVector());

		text2.setPosition(WVector2(500 / 2, 350).toWorldScreen().getSfmlVector());

		text2.setFont(font);

		text2.setString("VOLTAR");
		text2.setScale(WVector2(1, 1).toWorldScreen().getSfmlVector());

		text1.setScale(WVector2(1, 1).toWorldScreen().getSfmlVector());
	}

	inline void events(sf::Event &e) override
	{
		button.event(e);
		button1.event(e);
	}

	inline void update(const float &) override
	{
	}

	inline void render(sf::RenderWindow &window) override
	{
		window.draw(background);
		button.draw(window);
		button1.draw(window);
		window.draw(text1);
		window.draw(text2);
	}

	sf::Font font;
	sf::Text text1, text2;
	sf::Music *music;
	Button button, button1;

	sf::Sprite background;
};


class Author: public Scene
{
	public:
	  	inline void init() override

	{
		if (!texture.loadFromFile("./assets/autor.png"))
		{
		}

		background.setTexture(texture);

		background.setScale(WVector2(1, 1).toWorldScreen().getSfmlVector());

		main_menu.setPosition(WVector2(175, 800).getSfmlVector());
		main_menu.setSize(WVector2(200, 60).getSfmlVector());

		main_menu.setShowRectangle(false);

		main_menu.setCall([&]() {
		
			m_scenes->loadScene("MainMenu");
		});
	}

	inline void events(sf::Event &e) override
	{
		main_menu.event(e);
	}

	inline void update(const float &) override
	{
	}

	inline void render(sf::RenderWindow &window) override
	{
		window.draw(background);
		main_menu.draw(window);
	}

	sf::Texture texture;
	sf::Sprite background;
	Button main_menu;
};