#pragma once

#include "components.hpp"
#include "space_components.hpp"
#include "resurce.hpp"
#include "wvector2.hpp"

//class EnemySpawne;

class PlayerSpawner : public Ecs::System<Player>
{
	void init() override;

	void update(const float &dt) override;

	void newNave();

	void newBullet(const WVector2 &pos);

  public:
	Resources<std::string, sf::Texture> *m_textures;
	Resources<std::string,sf::SoundBuffer>* m_sounds;

	float time_num_bullets =25; ///tempo para diminuir o numero de balas

	float delta_time_num_bullets = time_num_bullets; //varia de forma regresiva se for 0 diminui o numero de balas

	int num_bullets = 1; //numero de balas a serem instanciadas

	float time_bullets = 0.5; // tempo levado para uma bala ser instanciada

	float delta_time_bullets = time_bullets; //varia o tempo se a delta_time_bullets for zero instancia uma bala

	int nave_healt = 3; //vida da nave se acabar o jogador perdeu
};

class InputSystem : public Ecs::System<InputComponent>
{
	sf::Vector2f touchOffset;
	void init() override;

	void update(const float &dt) override;

  public:
	void events(sf::Event &event);

	bool isTouching = false;
};

class BulletSystem : public Ecs::System<BulletTypeComponent>
{
	void init() override;

	void update(const float &dt) override;
};

///sistema que vai atualizar a entidade com para mostrar a vida do jogador na tela
class NaveHealthSystem : public Ecs::System<TextComponent>
{
	void init() override;

	void update(const float &dt) override;
	
	sf::Font font;
};


//destroi entidades com componente ResurceTypeComponent
class ResurceDestroy: public Ecs::System<ResurceTypeComponent>
{
	void init() override;

	void update(const float &dt) override;
	
	int background_count=0;
};

inline void newAnimatedEntity(Ecs::World* w,const sf::Vector2f& pos,sf::Texture& texture,float width,float heigth,int layer,int sx,int sy,int qx,int qy,float d)
{
	auto entity=w->addEntity();
	
	entity->addComponent<PositionComponent>()->position=pos;
	
	entity->addComponent<LayerComponent>()->layer=layer;
	
	auto sprite=entity->addComponent<SpriteComponent>();
	
	sprite->sprite.setTexture(texture);
	
	sprite->sprite.setScale(WVector2::toWorldScreen(width,heigth).getSfmlVector());
	
	auto animation=entity->addComponent<AnimatorComponent>();
	
	animation->animation=std::make_unique<Animation>(texture,sx,sy,qx,qy,d);
	entity->addComponent<ResurceTypeComponent>()->type=ResurceType::Animation;
	
}

inline void newBackGround(Ecs::World* w,const sf::Vector2f& pos,sf::Texture& texture,float width,float heigth)
{
	auto entity=w->addEntity();
	
	entity->addComponent<PositionComponent>()->position=WVector2(pos.x,pos.y).toWorldScreen().getSfmlVector();
	
	entity->addComponent<LayerComponent>()->layer=0;
	
	auto sprite=entity->addComponent<SpriteComponent>();
	
	sprite->sprite.setTexture(texture);
	
	sprite->sprite.setScale(WVector2::toWorldScreen(width,heigth).getSfmlVector());
	
	entity->addComponent<ResurceTypeComponent>()->type=ResurceType::BackGround;
	
	entity->addComponent<VelocityComponent>()->velocity.y=WVector2(0,50).toWorldScreen().y;
	
}