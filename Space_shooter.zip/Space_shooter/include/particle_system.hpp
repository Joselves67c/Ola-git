#pragma once

#include "particle.hpp"
#include <SFML/Graphics.hpp>
#include <random>

class ParticleSystem
{
  public:
	ParticleSystem(const unsigned int &);

	void update(const float &dt);

	void draw(sf::RenderWindow &window);

	void setPositionEmitter(const Math::Vector2 &pos);

	Math::Vector2 &getPositionEmitter();

	void setSpeed(const Math::Vector2 &v);

	void setDirection(const Math::Vector2 &dir);

	void setLifeTime(const Math::Vector2 &life);

	static double toRadian(const double &);

	void instanceParticles(Particle &);

	void initialize();

	float size;
	float size_velocity;
	float angular_velocity;
	Math::Vector2 force;
	sf::Color color;

  protected:
	Math::Vector2 position;
	Math::Vector2 speed;
	Math::Vector2 direction;
	Math::Vector2 lifetime;

	std::vector<Particle> particles;
	sf::VertexArray m_vertices;
	std::unique_ptr<std::mt19937> rng;
};