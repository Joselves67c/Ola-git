#pragma once

#include "world.hpp"
#include "SFML/Graphics.hpp"
#include "anim8.hpp"
#include "particle_system.hpp"

class SpriteComponent : public Ecs::Component
{
  public:
	sf::Sprite sprite;
};

class PositionComponent : public Ecs::Component
{
  public:
	sf::Vector2f position;

	PositionComponent();

	void addChild(PositionComponent *);
	sf::Vector2f getGlobalPosition();

	void destroyChild(const PositionComponent *const);
	PositionComponent *parent;
std::list<PositionComponent *> childs;
	
};

class AABBComponent : public Ecs::Component
{
  public:
	void setPosition(const sf::Vector2f &);

	void setSize(const sf::Vector2f &);

	sf::FloatRect aabb;

	bool drawing = true;

	sf::Vector2f position;
	sf::Vector2f size;
	std::function<void(Ecs::Entity *, Ecs::Entity *)> callible;
};

class RectangleComponent : public Ecs::Component
{
  public:
	sf::RectangleShape rect;
};

class VelocityComponent : public Ecs::Component
{
  public:
	sf::Vector2f velocity;
};

class LayerComponent : public Ecs::Component
{
  public:
	int layer = 0;
};

struct AnimatorComponent : Ecs::Component
{
  public:
	std::unique_ptr<Animation> animation;
};

struct ParticleSystemComponent : Ecs::Component
{
  public:
	std::unique_ptr<ParticleSystem> particle_system;
};

class InputComponent : public Ecs::Component
{
};

class TextComponent: public Ecs::Component
{
	public:
	  sf::Text text;
};