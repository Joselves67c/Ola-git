#include "space_math.hpp"

float clamp(const float &var, const float &min, const float &max)
{
	if(var<=min)
	{
	  return min;	
	}
	
	if(var>=max)
	{
		return max;
	}
	
	return var;
}