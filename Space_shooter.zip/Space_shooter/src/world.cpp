#include "world.hpp"

namespace Ecs
{
//adiciona uma entidade ao mundo
Entity *World::addEntity()
{
	auto entity = std::make_unique<Entity>(this);

	auto r_entity = entity.get();

	for (auto &system : this->systems)
	{
		entity->clientes.push_back(system.second.get());
	}

	this->entitys.push_back(std::move(entity));

	for (auto &client : clientes)
	{
		if (client)
		{
			client->notify(Info::addedEntity, r_entity);
		}
	}

	return r_entity;
}

//destroi uma entidade no mundo
void World::destroyEntity(const Entity *const entity)
{
	auto it = std::find_if(entitys.begin(), entitys.end(), [&](std::unique_ptr<Entity> &e) {
		if (e.get() == entity)
		{
			return true;
		}

		return false;
	});
	
	if(it!=entitys.cend())
	{
		for (auto &client : clientes)
	{
		if (client)
		{
			client->notify(Info::removedEntity, it->get());
		}
	}
		
		entitys.erase(it);
	}
}

//chamado uma unica vez
void World::init()
{
	for (auto &system : systems)
	{
		system.second->init();
	}
}

//chamado a cada frame
void World::update(const float &dt)
{
	for (auto &system : systems)
	{
		system.second->update(dt);
	}
}

//esta funçao esta definido no cabeçalho "entity.hpp"
//aqui é a sua implementaçao
void Entity::destroy()
{
	this->world->destroyEntity(this);
}
} // namespace Ecs