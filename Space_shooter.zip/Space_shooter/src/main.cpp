#include "game_states.hpp"
#include "wvector2.hpp"
#include "game_scenes.hpp"

class Game
{
  public:
	Game() : window(std::make_shared<sf::RenderWindow>(sf::VideoMode::getDesktopMode(), ""))
	{
		window->setFramerateLimit(60);
		window->setVerticalSyncEnabled(true);
		
		auto wsize=window->getSize();
		
		WVector2::descktopW=WVector2(wsize.x,wsize.y);
		WVector2::fixedWindow=WVector2(592,960);
		
		window->setFramerateLimit(60);
		window->setVerticalSyncEnabled(true);
		
		
		scenes.addScene<GameOver>("GameOver");
		scenes.addScene<Win>("Win");
		scenes.addScene<Intro>("Intro")->window=window.get();
		scenes.addScene<Pause>("Pause");
		scenes.addScene<Author>("Author");
		
		scenes.loadScene("Intro");
		
	}

	void run();

  private:
	void events(sf::Event &event)
	{
		scenes.events(event);
	}

	void update(const float &dt)
	{
		scenes.update(dt);
	}

	void render()
	{
		scenes.render(*window);
	}

	std::shared_ptr<sf::RenderWindow> window;
	SceneManager scenes;
	bool inFocus=true; //para de executar o quando jogo for minimizado
};

int main(int argc, char *argv[])
{
	Game *game = new Game();
	game->run();

	delete game;

	return EXIT_SUCCESS;
}

void Game::run()
{
	sf::Clock clock;
	while (window->isOpen())
	{
		auto delta = clock.restart().asSeconds();

		sf::Event event;
		while (window->pollEvent(event))
		{
			this->events(event);
			
			if(event.type==event.LostFocus)
			{
				window->close();
				window->create( sf::VideoMode::getDesktopMode(), "");
				
				window->setFramerateLimit(60);
		window->setVerticalSyncEnabled(true);
				inFocus=false;
			}
			
			if(event.type==event.GainedFocus)
			{
				inFocus=true;
			}
		}
		
			auto wsize=window->getSize();
		
		WVector2::descktopW=WVector2(wsize.x,wsize.y);
		WVector2::fixedWindow=WVector2(592,960);
     
     if(inFocus)
     {
		this->update(delta);
     }
		window->clear();
		this->render();
		window->display();
	}
}