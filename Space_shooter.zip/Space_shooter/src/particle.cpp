#include "particle.hpp"

Particle::Particle() : angular_velocity(0), size(0), life_time(0) {}

void Particle::update(const float &dt)
{
	position += (velocity * dt);

	velocity += (force * dt);

	force.x=0; force.y=0;

	life_time -=2*dt;

	orientation += angular_velocity * dt;

	size += sizeVelocity * dt;
}

void Particle::setPosition(const float &x, const float &y)
{
	this->position = Math::Vector2(x, y);
}

const Math::Vector2 &Particle::getPosition() const
{
	return this->position;
}

void Particle::setVelocity(const float &x, const float &y)
{
	this->velocity = Math::Vector2(x, y);
}

const Math::Vector2 &Particle::getVelocity() const
{
	return this->velocity;
}

void Particle::addForce(const float &x, const float &y)
{
	this->force += Math::Vector2(x, y);
}

void Particle::setLifeTime(const float &t)
{
	this->life_time = t;
}

const float &Particle::getLifeTime() const
{
	return this->life_time;
}

void Particle::setSize(const float &s)
{
	this->size = s;
}

const float &Particle::getSize() const
{
	return this->size;
}

void Particle::setAngularVelocity(const float &v)
{
	this->angular_velocity = v;
}

const float &Particle::getAngularVelocity() const
{
	return this->angular_velocity;
}

void Particle::setOrientation(const float &o)
{
	this->orientation = o;
}

const float &Particle::getOrientation() const
{
	return this->orientation;
}

void Particle::setSizeVelocity(const float &sv)
{
	this->sizeVelocity = sv;
}

const float &Particle::getSizeVelocity() const
{
	return sizeVelocity;
}