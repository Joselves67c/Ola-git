#include "button.hpp"
#include "wvector2.hpp"

Button::Button() : m_render(true)
{
}
void Button::setPosition(const sf::Vector2f &position)
{
	m_boundbox = sf::FloatRect(position, m_rectangle.getSize());

	m_rectangle.setPosition(position);
}

void Button::setColor(const sf::Color &color)
{
	m_rectangle.setFillColor(color);
}

void Button::setSize(const sf::Vector2f &size)
{
	m_rectangle.setSize(size);
	m_boundbox = sf::FloatRect(m_rectangle.getPosition(), size);
}

void Button::setShowRectangle(const bool &rende)
{
	m_render = rende;
}

void Button::event(sf::Event &event)
{
	if (event.type == event.TouchBegan)
	{
		sf::Vector2f touch_position = sf::Vector2f(event.touch.x, event.touch.y);

auto pos = WVector2(m_rectangle.getPosition().x, m_rectangle.getPosition().y).toWorldScreen().getSfmlVector();

	auto size = WVector2(m_rectangle.getSize().x, m_rectangle.getSize().y).toWorldScreen().getSfmlVector();


		auto bound = sf::FloatRect(pos,size);

		if (bound.contains(touch_position))
		{
			m_callable();
		}
	}
}

void Button::draw(sf::RenderWindow &window)
{
	auto pos = WVector2(m_rectangle.getPosition().x, m_rectangle.getPosition().y).toWorldScreen().getSfmlVector();

	auto size = WVector2(m_rectangle.getSize().x, m_rectangle.getSize().y).toWorldScreen().getSfmlVector();


	if (m_render)
	{
		
		sf::RectangleShape r(size);
		r.setPosition(pos);
		window.draw(r);
	}
}

void Button::setCall(std::function<void()> call)
{
	m_callable = call;
}