#include "scenes_manager.hpp"

void SceneManager::destroyScene(const std::string &name)
{
	auto it=this->m_scenes.find(name);
	
	if(it!=this->m_scenes.cend())
	{
		this->m_scenes.erase(it);
	}
}

void SceneManager::loadScene(const std::string &name)
{
	this->m_currentScene=name;
}

void SceneManager::events(sf::Event &event)
{
	this->m_scenes.at(this->m_currentScene)->events(event);
}

void SceneManager::update(const float &dt)
{this->m_scenes.at(this->m_currentScene)->update(dt);
}

void SceneManager::render(sf::RenderWindow &window)
{
	this->m_scenes.at(this->m_currentScene)->render(window);
}