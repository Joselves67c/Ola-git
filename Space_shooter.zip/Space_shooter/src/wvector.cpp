#include "wvector2.hpp"


float convert(float dx,float setx,float v)
{
	return (v*setx)/dx;
	
}

WVector2::WVector2(const float &fx, const float &fy):Math::Vector2(fx,fy)
{
	
}

WVector2 WVector2::toWorldScreen() const
{
	return WVector2(convert(fixedWindow.x,x,descktopW.x),convert(fixedWindow.y,y,descktopW.y));
}

WVector2 WVector2::toWorldScreen(const float & fx, const float &fy)
{
	return WVector2(convert(fixedWindow.x,fx,descktopW.x),convert(fixedWindow.y,fy,descktopW.y));
}

sf::Vector2f WVector2::getSfmlVector() const
{
	return sf::Vector2f(x,y);
}

WVector2 WVector2::descktopW;
WVector2 WVector2::fixedWindow;

