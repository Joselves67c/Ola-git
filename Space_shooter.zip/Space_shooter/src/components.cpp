#include "components.hpp"

PositionComponent::PositionComponent() : parent(nullptr) {}

void PositionComponent::addChild(PositionComponent *position)
{
	position->parent = this;
	this->childs.push_back(position);
}
sf::Vector2f PositionComponent::getGlobalPosition()
{
	auto mparent = this->parent;
	sf::Vector2f global_pos = this->position;
	while (mparent != nullptr)
	{
		global_pos += mparent->position;

		mparent = mparent->parent;
	}
	return global_pos;
}

void PositionComponent::destroyChild(const PositionComponent *const _position)
{
	auto it = std::find_if(childs.cbegin(), childs.cend(), [&](PositionComponent *p) {
		if (p == _position)
		{
			return true;
		}

		return false;
	});

	if (it != childs.cend())
	{
		printf("enxiste");

		(*it)->parent = nullptr;

		this->childs.erase(it);
	}
}

void AABBComponent::setPosition(const sf::Vector2f &p)
{
	position = p;
	aabb = sf::FloatRect(position, size);
}

void AABBComponent::setSize(const sf::Vector2f &s)
{
	size = s;
	aabb = sf::FloatRect(position, size);
}

