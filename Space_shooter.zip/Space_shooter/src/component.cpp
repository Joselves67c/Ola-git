#include "component.hpp"
#include <iostream>

namespace Ecs
{
	//implementaçao do destruidor padrao pata todos os componentes porem pode ser subistituido
	Component::~Component()
	{
		//imprima uma informaçao
	//	std::cout<<"Component Destruido\n";
	}
	
}