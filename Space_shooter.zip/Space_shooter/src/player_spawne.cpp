#include "player_spawne.hpp"
#include "space_math.hpp"
#include <array>
#include "enemy_spawner.hpp"

////sistema do player do jogo
void PlayerSpawner::init()
{
	newNave();
}

void PlayerSpawner::update(const float &dt)
{
	//posicao que a nave seguira ao ser instanciada;
	sf::Vector2f targetPosition(WVector2((592 / 2) - 50, 960 / 2).toWorldScreen().getSfmlVector());

	float v_speed = WVector2(0,400).toWorldScreen().y; //velocidade da nave ao seguir a targetPosition

	auto _entitys = getEntitys();

	if (_entitys.end() - _entitys.begin() == 0)
	{
		if (nave_healt > 0)
		{
			newNave();
		}
	}

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			auto velocity = entity.lock()->getComponent<VelocityComponent>();

			auto position = entity.lock()->getComponent<PositionComponent>();

			auto defese = entity.lock()->getComponent<DefeseComponent>();

			if (defese)
			{
				defese->time -= 2 * dt;

				if (defese->time <= 0)
				{
					entity.lock()->destroyComponent<DefeseComponent>();
				}
			}

			if (velocity)
			{
				auto target = targetPosition - position->position;

				WVector2 speed(target.x, target.y);

				speed.normalize();
				speed *= v_speed;

				velocity->velocity = speed.getSfmlVector();

				if (WVector2(target.x, target.y).magnitude() <= 30)
				{
					entity.lock()->destroyComponent<VelocityComponent>();
				}
			}
			else
			{
				WVector2 x_size = WVector2(0, 592 - 150).toWorldScreen();
				WVector2 y_size = WVector2(0, 960 - 100).toWorldScreen();

				position->position.x = clamp(position->position.x, x_size.x, x_size.y);

				position->position.y = clamp(position->position.y, y_size.x, y_size.y);
			}

			/// instacia balas
			if (delta_time_bullets <= 0)
			{
				newBullet(WVector2(position->position.x, position->position.y));

				delta_time_bullets = time_bullets;
			}

			delta_time_bullets -= 2 * dt;

			//diminui o numero de balas se a condicao for atendida

			if (this->delta_time_num_bullets <= 0)
			{
				num_bullets--;

				this->delta_time_num_bullets = this->time_num_bullets;
			}

			delta_time_num_bullets -= 2 * dt;

			num_bullets = clamp(num_bullets, 1, 3);
			
			nave_healt=clamp(nave_healt,0,4);
		}
	}
}

void PlayerSpawner::newNave()
{
	auto nave = world->addEntity();

	auto position = nave->addComponent<PositionComponent>();

	auto sprite = nave->addComponent<SpriteComponent>();

	nave->addComponent<VelocityComponent>();

	auto collider = nave->addComponent<AABBComponent>();
	nave->addComponent<Player>();

	nave->addComponent<LayerComponent>()->layer = 4;

	nave->addComponent<InputComponent>();

	position->position = WVector2((592 / 2) - 50, 970).toWorldScreen().getSfmlVector();

	sprite->sprite.setTexture(m_textures->get("Nave"));
	sprite->sprite.setScale(WVector2::toWorldScreen(0.2, 0.2).getSfmlVector());

	nave->addComponent<DefeseComponent>()->time = 8;

	/// colisao da nave

	collider->setSize(WVector2::toWorldScreen(100, 100).getSfmlVector());
	collider->drawing = false;
	collider->callible = [&](Ecs::Entity *a, Ecs::Entity *b) {
		auto _player = a->getComponent<Player>();

		auto _bullet = b->getComponent<BulletTypeComponent>();

		auto _health = b->getComponent<HealthComponent>();
		
		auto pos=a->getComponent<PositionComponent>();

		if (_player)
		{
			if (_bullet)
			{
				if (_bullet->bullet_type == BulletType::Enemy)
				{
					auto defese = a->getComponent<DefeseComponent>();
					b->destroy();

					if (!defese)
					{
						this->nave_healt--;
						auto input_system = world->getSystem<InputSystem>();

						auto nave_sound = world->addEntity();

						auto sound = nave_sound->addComponent<SoundComponent>();

						sound->sound.setBuffer(m_sounds->get("NaveSoundExplode"));

						//	sound->sound.setVolume(15);

						sound->sound.play();
						nave_sound->addComponent<ResurceTypeComponent>()->type = ResurceType::Sound;
						
						newAnimatedEntity(world,pos->getGlobalPosition()+WVector2(-25,-10).toWorldScreen().getSfmlVector(),m_textures->get("NaveExplode"),2,2,10,64,64,15,2,0.02);

						input_system->isTouching = false;
						a->destroy();
					}
				}
			}

			if (_health)
			{
				this->nave_healt--;
				auto input_system = world->getSystem<InputSystem>();

				auto nave_sound = world->addEntity();

				auto sound = nave_sound->addComponent<SoundComponent>();

				sound->sound.setBuffer(m_sounds->get("NaveSoundExplode"));

				//	sound->sound.setVolume(15);

				sound->sound.play();
				nave_sound->addComponent<ResurceTypeComponent>()->type = ResurceType::Sound;
				
newAnimatedEntity(world,pos->getGlobalPosition()+WVector2(-25,-10).toWorldScreen().getSfmlVector(),m_textures->get("NaveExplode"),2,2,10,64,64,15,2,0.02);

				input_system->isTouching = false;
				a->destroy();
			}
		}
	};
}

void PlayerSpawner::newBullet(const WVector2 &position)
{
	std::array<Math::Vector2, 4> positions;
	positions.at(0) = position + WVector2(34, 0).toWorldScreen();
	positions.at(1) = position + WVector2(4, 20).toWorldScreen();
	positions.at(2) = position + WVector2(67, 20).toWorldScreen();
	//positions.at()

	for (int i = 0; i != num_bullets; i++)
	{
		auto bullet = world->addEntity();

		auto position = bullet->addComponent<PositionComponent>();

		auto sprite = bullet->addComponent<SpriteComponent>();

		auto collider = bullet->addComponent<AABBComponent>();

		auto velocity = bullet->addComponent<VelocityComponent>();

		bullet->addComponent<BulletTypeComponent>()->bullet_type = BulletType::Player;
		bullet->addComponent<LayerComponent>()->layer = 1;

		position->position = sf::Vector2f(positions.at(i).x, positions.at(i).y);

float vy=WVector2(0,-800).toWorldScreen().y;
		velocity->velocity = sf::Vector2f(0, vy);

		sprite->sprite.setTexture(m_textures->get("BulletPlayer"));

		sprite->sprite.setScale(WVector2::toWorldScreen(0.8, 0.8).getSfmlVector());

		collider->setSize(WVector2::toWorldScreen(28, 40).getSfmlVector());
		collider->callible = [&](Ecs::Entity *a, Ecs::Entity *b) {};

		collider->drawing = false;

		bullet->addComponent<DamageComponent>()->damage = 1;
	}

	auto bullet_sound = world->addEntity();

	auto sound = bullet_sound->addComponent<SoundComponent>();

	sound->sound.setBuffer(m_sounds->get("BulletShoot"));

	sound->sound.setVolume(15);

	sound->sound.play();
	bullet_sound->addComponent<ResurceTypeComponent>()->type = ResurceType::Sound;
}

/////Sistema de entrada

void InputSystem::init()
{
}

void InputSystem::update(const float &dt)
{
}

void InputSystem::events(sf::Event &event)
{
	auto _entitys = getEntitys();

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			auto position = entity.lock()->getComponent<PositionComponent>();

			if (event.type == sf::Event::TouchBegan)
			{
				isTouching = true;
				touchOffset.x = event.touch.x - position->position.x;
				touchOffset.y = event.touch.y - position->position.y;
				if (position->position.y < WVector2(0, 960 - 100).toWorldScreen().y)
				{
					entity.lock()->destroyComponent<VelocityComponent>();
				}
			}
			if (event.type == sf::Event::TouchEnded)
			{
				isTouching = false;
			}

			if (event.type == sf::Event::TouchMoved && isTouching)
			{
				position->position = sf::Vector2f(event.touch.x - touchOffset.x, event.touch.y - touchOffset.y);

				if (position->position.y < WVector2(0, 960 - 100).toWorldScreen().y)
				{
					entity.lock()->destroyComponent<VelocityComponent>();
				}
			}

		} ///if expired
	}
}

////sistema para balas

void BulletSystem::init()
{
}

void BulletSystem::update(const float &dt)
{
	auto _entitys = getEntitys();

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			auto position = entity.lock()->getComponent<PositionComponent>();

			auto type = entity.lock()->getComponent<BulletTypeComponent>();

			if (type->bullet_type == BulletType::Player && position->position.y < WVector2(0, -20).toWorldScreen().y)
			{
				entity.lock()->destroy();
			}

			if (type->bullet_type == BulletType::Enemy && position->position.y > WVector2(0, 980).toWorldScreen().y)
			{
				entity.lock()->destroy();
			}
		}
	}
}

///sistema que vai atualizar a entidade com para mostrar a vida do jogador na tela

void NaveHealthSystem::init()
{
	if (!font.loadFromFile("/system/fonts/Roboto-Regular.ttf"))
	{
		throw std::runtime_error("FONTE NAO ENCONTRADA");
	}

	auto text_entity = world->addEntity();

	text_entity->addComponent<PositionComponent>()->position = WVector2(0, 20).toWorldScreen().getSfmlVector();
	
	text_entity->addComponent<TextTypeComponent>()->type=TextType::Health;

	text_entity->addComponent<LayerComponent>()->layer = 7;

	auto text = text_entity->addComponent<TextComponent>();

	text->text.setScale(WVector2::toWorldScreen(1, 1).getSfmlVector());

	text->text.setFont(font);
	
	
	auto text_round= world->addEntity();

	text_round->addComponent<PositionComponent>()->position = WVector2(0, 45).toWorldScreen().getSfmlVector();
	
	text_round->addComponent<TextTypeComponent>()->type=TextType::Round;

	text_round->addComponent<LayerComponent>()->layer = 7;

	auto textr= text_round->addComponent<TextComponent>();

	textr->text.setScale(WVector2::toWorldScreen(1, 1).getSfmlVector());

	textr->text.setFont(font);
}

void NaveHealthSystem::update(const float &dt)
{
	auto _entitys = getEntitys();

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			
			auto text = entity.lock()->getComponent<TextComponent>();
			
			auto text_type=entity.lock()->getComponent<TextTypeComponent>();
			
			if(text_type->type==TextType::Health)
             {
             	auto player_spawner = world->getSystem<PlayerSpawner>();

			text->text.setString("VIDA :" + std::to_string(player_spawner->nave_healt));
			
             }
             if(text_type->type==TextType::Round)
             {
             	auto enemy_spawner=world->getSystem<EnemySpawne>();
             	
             	text->text.setString("ONDA :" + std::to_string(enemy_spawner->rounds));
             }
             
		}
	}
}

/// sistemema que /destroi entidades com componente ResurceTypeComponent
void ResurceDestroy::init()
{
	background_count++;
	auto player_spawner = world->getSystem<PlayerSpawner>();

	newBackGround(world, sf::Vector2f(0, 0), player_spawner->m_textures->get("BackGround"), 1, 1);

	//newBackGround(world, sf::Vector2f(0, -960), player_spawner->m_textures->get("BackGround"), 1, 1);
}

void ResurceDestroy::update(const float &dt)
{
	auto _entitys = getEntitys();

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			auto resurce = entity.lock()->getComponent<ResurceTypeComponent>();

			if (resurce->type == ResurceType::Sound)
			{
				auto sound = entity.lock()->getComponent<SoundComponent>();
				if (sound->sound.getStatus() == sf::Sound::Stopped)
				{
					entity.lock()->destroy();
				}
			}

			if (resurce->type == ResurceType::Animation)
			{
				auto anim = entity.lock()->getComponent<AnimatorComponent>();

				if (anim->animation->getCurrentFrame() == anim->animation->m_frames.size() - 1)
				{
					entity.lock()->destroy();
				}
			}

			if (resurce->type == ResurceType::BackGround)
			{
				auto position = entity.lock()->getComponent<PositionComponent>();

				auto vec = WVector2(960, -500).toWorldScreen();

				if (position->position.y >= 0 && background_count <= 1)
				{
					background_count++;
					auto player_spawner = world->getSystem<PlayerSpawner>();
					newBackGround(world, sf::Vector2f(0, -960), player_spawner->m_textures->get("BackGround"), 1, 1);
				}

				if (position->position.y >= vec.x)
				{
					background_count--;
					entity.lock()->destroy();
				}
			}
		}
	}
}
