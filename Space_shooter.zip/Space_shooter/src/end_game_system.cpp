#include "end_game_system.hpp"
#include "enemy_spawner.hpp"
#include "player_spawne.hpp"

void EndGameSystem::init()
{
	auto over=world->addEntity();
	auto end_over=over->addComponent<EndGameComponent>();
	
	end_over->time=8;
	end_over->status=Status::GameOver;
	
		auto win=world->addEntity();
	auto end_win=win->addComponent<EndGameComponent>();
	
	end_win->time=8;
	end_over->status=Status::Win;
	
}

void EndGameSystem::update(const float &dt)
{
	auto _entitys=getEntitys();
	
	for(auto& entity:_entitys)
	{
		if(!entity.expired())
		{
			auto end=entity.lock()->getComponent<EndGameComponent>();
			
			if(end->status==Status::GameOver)
			{
				auto player_spawner=world->getSystem<PlayerSpawner>();
				
				if(player_spawner->nave_healt<=0)
				{
					end->time-=2*dt;
				}
				
				if(end->time<=0)
				{
					m_scenes->loadScene("GameOver");
				}
			}
			
				if(end->status==Status::Win)
			{
				auto enemy_spawner=world->getSystem<EnemySpawne>();
				
				if(enemy_spawner->rounds<=0)
				{
					end->time-=2*dt;
				}
				
				if(end->time<=0)
				{
					m_scenes->loadScene("Win");
				}
			}
		}
	}
}