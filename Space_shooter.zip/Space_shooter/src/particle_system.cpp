#include "particle_system.hpp"
#include <array>

ParticleSystem::ParticleSystem(const unsigned int &count) : particles(count), m_vertices(sf::Triangles), rng(std::make_unique<std::mt19937>(std::random_device()()))
{
	size = 1;
	size_velocity = 0;
	angular_velocity = 0;
}

void ParticleSystem::initialize()
{
	for (auto &p : particles)
	{
		instanceParticles(p);
		p.update(0.001);
	}
}

void ParticleSystem::update(const float &dt)
{
	typedef sf::Vector2f V;

	m_vertices.resize(particles.size() * 6);

	unsigned int i = 0;
	for (auto &p : this->particles)
	{
		p.update(dt);

		float orientation = p.getOrientation();
		V position(p.getPosition().x, p.getPosition().y);
		p.addForce(force.x, force.y);

		if (p.getLifeTime() <= 0)
		{
			this->instanceParticles(p);
		}

		sf::Vector2f size(p.getSize() / 2, p.getSize() / 2);

		std::array<sf::Vector2f, 6> axes{V(-size.x, size.y), V(size.x, size.y), V(size.x, -size.y), V(size.x, -size.y), V(-size.x, -size.y), V(-size.x, size.y)};

		for (int v = 0; v != axes.size(); v++)
		{
			float x = axes[v].x * cos(orientation) - axes[v].y * sin(orientation);
			float y = axes[v].x * sin(orientation) + axes[v].y * cos(orientation);

			m_vertices[i * 6 + v].position = position + V(x, y);
			m_vertices[i * 6 + v].color = color;
		}
		i++;
	}
}

void ParticleSystem::instanceParticles(Particle &particle)
{
	particle.setPosition(position.x, position.y);
	float random_dir = std::uniform_real_distribution<float>(direction.x, direction.y)(*rng);

	float random_speed = std::uniform_real_distribution<float>(speed.x, speed.y)(*rng);

	double random_lifeTime = std::uniform_real_distribution<double>(lifetime.x, lifetime.y)(*rng);

	particle.setVelocity(cos(random_dir) * random_speed, sin(random_dir) * random_speed);

	particle.setLifeTime(random_lifeTime);
	particle.setAngularVelocity(angular_velocity);

	particle.setSizeVelocity(size_velocity);

	particle.setSize(size);
}

void ParticleSystem::draw(sf::RenderWindow &window)
{
	window.draw(m_vertices);
}

void ParticleSystem::setPositionEmitter(const Math::Vector2 &pos)
{
	this->position = pos;
}

Math::Vector2 &ParticleSystem::getPositionEmitter()
{
	return this->position;
}

void ParticleSystem::setSpeed(const Math::Vector2 &v)
{
	this->speed = v;
}

void ParticleSystem::setDirection(const Math::Vector2 &dir)
{
	this->direction = Math::Vector2(toRadian(dir.x), toRadian(dir.y));
}

void ParticleSystem::setLifeTime(const Math::Vector2 &life)
{
	this->lifetime = life;
}

double ParticleSystem::toRadian(const double &grau)
{
	double PI = 3.14159;

	return (PI * grau) / 180;
}

