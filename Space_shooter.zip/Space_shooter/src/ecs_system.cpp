#include "ecs_system.hpp"

namespace Ecs
{
namespace NSystem
{
	void deleter(Ecs::Entity* entity)
	{
		
	}
}
}