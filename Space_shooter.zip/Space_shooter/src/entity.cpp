#include "entity.hpp"

namespace Ecs
{
//construtor padrao para a entidade
Entity::Entity(World *w) : world(w) {}

} // namespace Ecs