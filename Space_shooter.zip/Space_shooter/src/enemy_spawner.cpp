#include "enemy_spawner.hpp"
#include "wvector2.hpp"
#include <random>
#include <array>
#include "player_spawne.hpp"

void EnemySpawne::newEmmoPack(sf::Vector2f pos)
{
	auto emmo= world->addEntity();
					auto position =emmo->addComponent<PositionComponent>();

					auto sprite = emmo->addComponent<SpriteComponent>();

					auto collider =emmo->addComponent<AABBComponent>();

					auto velocity = emmo->addComponent<VelocityComponent>();
					
					emmo->addComponent<ItemTypeComponent>()->item_type=ItemType::Emmo;
					position->position=pos;
				
					emmo->addComponent<LayerComponent>()->layer = 1;

float vy=WVector2(0,250).toWorldScreen().y;
					velocity->velocity = sf::Vector2f(0, vy);

					sprite->sprite.setTexture(world->getSystem<EnemySpawne>()->m_textures->get("Emmo"));

					sprite->sprite.setScale(WVector2::toWorldScreen(0.3, 0.3).getSfmlVector());

					collider->setSize(WVector2::toWorldScreen(75, 60).getSfmlVector());
					collider->callible = [&](Ecs::Entity *a, Ecs::Entity *b) {
			auto item=a->getComponent<ItemTypeComponent>();
			
			if(item)
			{
				auto player=b->getComponent<Player>();
				
				if(player)
				{
					if(item->item_type==ItemType::Emmo)
					{
						auto player_spawne=world->getSystem<PlayerSpawner>();
						
						player_spawne->num_bullets++;
						player_spawne->delta_time_num_bullets=player_spawne->time_num_bullets;
					
						//som ao adiquir o pacote	
					auto bullet_sound = world->addEntity();

auto player_spawner=world->getSystem<PlayerSpawner>();

		auto sound = bullet_sound->addComponent<SoundComponent>();

		sound->sound.setBuffer(player_spawner->m_sounds->get("SoundPacks"));
		
	//	sound->sound.setVolume(15);

		sound->sound.play();
		bullet_sound->addComponent<ResurceTypeComponent>()->type = ResurceType::Sound;
						//fim
						a->destroy();
					}
				}
				
			}
	};

					collider->drawing = false;
					
				
}

void EnemySpawne::newHealtPack(sf::Vector2f pos)
{
	auto emmo= world->addEntity();
					auto position =emmo->addComponent<PositionComponent>();

					auto sprite = emmo->addComponent<SpriteComponent>();

					auto collider =emmo->addComponent<AABBComponent>();

					auto velocity = emmo->addComponent<VelocityComponent>();
					emmo->addComponent<ItemTypeComponent>()->item_type=ItemType::Health;
					
					position->position=pos;
				
					emmo->addComponent<LayerComponent>()->layer = 1;
float vy=WVector2(0,250).toWorldScreen().y;
					velocity->velocity = sf::Vector2f(0, vy);

					sprite->sprite.setTexture(world->getSystem<EnemySpawne>()->m_textures->get("Health"));

					sprite->sprite.setScale(WVector2::toWorldScreen(0.3, 0.3).getSfmlVector());

					collider->setSize(WVector2::toWorldScreen(75, 60).getSfmlVector());
					collider->callible = [&](Ecs::Entity *a, Ecs::Entity *b) {
						auto item=a->getComponent<ItemTypeComponent>();
			
			if(item)
			{
				auto player=b->getComponent<Player>();
				
				if(player)
				{
					if(item->item_type==ItemType::Health)
					{
						auto player_spawne=world->getSystem<PlayerSpawner>();
						
						player_spawne->nave_healt++;
						
						//som ao adiquirir o pacote
									auto bullet_sound = world->addEntity();

auto player_spawner=world->getSystem<PlayerSpawner>();

		auto sound = bullet_sound->addComponent<SoundComponent>();

		sound->sound.setBuffer(player_spawner->m_sounds->get("SoundPacks"));
		
	//	sound->sound.setVolume(15);

		sound->sound.play();
		bullet_sound->addComponent<ResurceTypeComponent>()->type = ResurceType::Sound;
		
		//fim
						
						a->destroy();
					}
				}
				
			}
	};

					collider->drawing = false;
					
					
}

void EnemySpawne::init()
{
	rng = std::make_unique<std::mt19937>(std::random_device()());
}
void EnemySpawne::update(const float &dt)
{
	sf::Vector2f targetPos = WVector2(0, 960 / 2).toWorldScreen().getSfmlVector();

	float speed = WVector2(0,400).toWorldScreen().y;

	auto _entitys = getEntitys();

	if (this->rounds >0)
	{
		if ((_entitys.end() - _entitys.begin()) == 0)
		{
			newEnemys();
		}
	}

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			auto position = entity.lock()->getComponent<PositionComponent>();

			auto velocity = entity.lock()->getComponent<VelocityComponent>();
			if (velocity)
			{
				sf::Vector2f target = targetPos - position->position;

				WVector2 dir(target.x, target.y);

				dir.normalize();

				dir *= speed;

				velocity->velocity.y = dir.getSfmlVector().y;
			}

			if (position->childs.size() == 0)
			{
				entity.lock()->destroy();

				rounds--;
				health++;
			}
		}
	}
}

void EnemySpawne::newEnemys()
{
	std::array<std::array<Selection, 3>, 5> radom_emmo;
	
	

	radom_emmo.at(std::uniform_int_distribution<int>(0, 4)(*rng)).at(std::uniform_int_distribution<int>(0, 2)(*rng)) = Selection{true,(bool)std::uniform_int_distribution<int>(0,1)(*rng)};

	auto dad = world->addEntity();

	auto position = dad->addComponent<PositionComponent>();

	dad->addComponent<VelocityComponent>();

	dad->addComponent<EnemyComponent>();

	position->position = WVector2((592 / 2), -50).toWorldScreen().getSfmlVector();

	//velocity->velocity = sf::Vector2f(0, 50);

	sf::Vector2f size = WVector2::toWorldScreen(100, 100).getSfmlVector();
	auto delta = WVector2((-592 / 2) + 50, -300).toWorldScreen();

	for (int i = 0; i != 5; i++)
	{
		for (int j = 0; j != 3; j++)
		{
			auto child = world->addEntity();
			auto cposition = child->addComponent<PositionComponent>();
			auto sprite = child->addComponent<SpriteComponent>();
			child->addComponent<LayerComponent>()->layer = 3;
			child->addComponent<HealthComponent>()->health = this->health;
			auto ai = child->addComponent<AiDecisonComponent>();

			auto collider = child->addComponent<AABBComponent>();

			collider->setSize(WVector2::toWorldScreen(78, 74).getSfmlVector());

			collider->callible = [&](Ecs::Entity *a, Ecs::Entity *b) {
				auto damage = b->getComponent<DamageComponent>();
				auto type = b->getComponent<BulletTypeComponent>();
				
				auto pos_bullet=b->getComponent<PositionComponent>();
				
				auto h = a->getComponent<HealthComponent>();

				if (type)
				{
					if (type->bullet_type == BulletType::Player && h)
					{
						
						auto player_spaw=world->getSystem<PlayerSpawner>();
						
                           newAnimatedEntity(world,pos_bullet->getGlobalPosition()+WVector2(-10,-15).toWorldScreen().getSfmlVector(),player_spaw->m_textures->get("BulletExplode"),0.5,0.5,1,100,100,10,8,0.01);
                           
						
						h->health -= damage->damage;
						b->destroy();
						
						///instancie um som de explosao da bala
						  auto player_spawner=world->getSystem<PlayerSpawner>();
						  
						  
						auto bullet_expl=  world->addEntity();
						
						auto sound=bullet_expl->addComponent<SoundComponent>();
						sound->sound.setBuffer(player_spawner->m_sounds->get("BulletExplosion"));
						
						sound->sound.play();
						bullet_expl->addComponent<ResurceTypeComponent>()->type=ResurceType::Sound;
						///fim
						
						if (h->health <= 0)
						{
							auto pos = a->getComponent<PositionComponent>();
							
							auto emmo=a->getComponent<SelectionComponent>();
							
							if(emmo->selected.isSelected)
							{
								if(emmo->selected.item==1)
								{
									newEmmoPack(pos->getGlobalPosition());
								}
								
								if(emmo->selected.item==0)
								{
									newHealtPack(pos->getGlobalPosition());
								}
							}
							
							
							  auto player_spawner=world->getSystem<PlayerSpawner>();
						  
						  
						  ///instancie som de explosao para o inimigo 
						  
						auto enemy_expl=  world->addEntity();
						
						auto esound=enemy_expl->addComponent<SoundComponent>();
						esound->sound.setBuffer(player_spawner->m_sounds->get("EnemyExplosion"));
						
						esound->sound.play();
						enemy_expl->addComponent<ResurceTypeComponent>()->type=ResurceType::Sound;
						
						///fim
                           
                           newAnimatedEntity(world,pos->getGlobalPosition()+WVector2(-25,-10).toWorldScreen().getSfmlVector(),player_spawner->m_textures->get("NaveExplode"),2,2,10,64,64,15,2,0.02);
                           
							pos->parent->destroyChild(pos);
							a->destroy();
						}
					}
				}
			};

			collider->drawing = false;

			ai->atack_probability = 6;
			ai->time = 1;

			sprite->sprite.setTexture(m_textures->get("Enemy"));

			sprite->sprite.setScale(WVector2::toWorldScreen(0.15, 0.15).getSfmlVector());

			cposition->position.x = size.x * i + delta.x;
			cposition->position.y = size.y * j + delta.y;

			position->addChild(cposition);

			auto selec = child->addComponent<SelectionComponent>();

			selec->selected = radom_emmo.at(i).at(j);
		}
	}
}

/////Sistema de decisao de ai
void AiDecisionSystem::init()
{
	rng = std::make_unique<std::mt19937>(std::random_device()());
}

void AiDecisionSystem::update(const float &dt)
{
	elapsedTime += dt;

	auto _entitys = getEntitys();

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			auto ai = entity.lock()->getComponent<AiDecisonComponent>();
			auto eposition = entity.lock()->getComponent<PositionComponent>();

			ai->elapsedTime += dt;

			auto seconds = ai->time - ai->elapsedTime;

			if (seconds <= 0)
			{
				int res = std::uniform_int_distribution<int>(0, ai->atack_probability)(*rng);

				if (res == 0)
				{
					//ai->callible();

					auto bullet = world->addEntity();
					auto position = bullet->addComponent<PositionComponent>();

					auto sprite = bullet->addComponent<SpriteComponent>();

					auto collider = bullet->addComponent<AABBComponent>();

					auto velocity = bullet->addComponent<VelocityComponent>();

					bullet->addComponent<BulletTypeComponent>()->bullet_type = BulletType::Enemy;
					bullet->addComponent<LayerComponent>()->layer = 1;

					position->position = eposition->getGlobalPosition() + WVector2(27, 0).toWorldScreen().getSfmlVector();
       float vy=WVector2(0,300).toWorldScreen().y;
					velocity->velocity = sf::Vector2f(0,vy);

					sprite->sprite.setTexture(world->getSystem<EnemySpawne>()->m_textures->get("BulletEnemy"));

					sprite->sprite.setScale(WVector2::toWorldScreen(0.3, 0.3).getSfmlVector());

					collider->setSize(WVector2::toWorldScreen(15, 50).getSfmlVector());
					collider->callible = [&](Ecs::Entity *a, Ecs::Entity *b) {};

					collider->drawing = false;
					
						///instancie um som de explosao da bala
						  auto player_spawner=world->getSystem<PlayerSpawner>();
						  
						  
						auto bullet_enemy_shoot=  world->addEntity();
						
						auto sound=bullet_enemy_shoot->addComponent<SoundComponent>();
						sound->sound.setBuffer(player_spawner->m_sounds->get("BulletEnemyShoot"));
						
						sound->sound.play();
						bullet_enemy_shoot->addComponent<ResurceTypeComponent>()->type=ResurceType::Sound;
						///fim
				}
				ai->elapsedTime = 0;
				
				
			}
		}
	}
}