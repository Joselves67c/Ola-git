#include "engine_systems.hpp"

////funcoes locais

void drawComponents(Ecs::Entity *entity, sf::RenderWindow &window)
{
	auto position = entity->getComponent<PositionComponent>();

	auto sprite = entity->getComponent<SpriteComponent>();

	auto rect = entity->getComponent<RectangleComponent>();

	auto aabb = entity->getComponent<AABBComponent>();

	auto particle = entity->getComponent<ParticleSystemComponent>();

	auto animator = entity->getComponent<AnimatorComponent>();

	auto text = entity->getComponent<TextComponent>();

	if (aabb)
	{
		if (aabb->drawing)
		{
			aabb->setPosition(position->getGlobalPosition());

			sf::RectangleShape r(aabb->size);
			r.setPosition(aabb->position);

			window.draw(r);
		}
	}

	if (rect)
	{
		sf::Transformable t;
		t.setPosition(position->getGlobalPosition());

		window.draw(rect->rect, t.getTransform());
	}

	if (sprite)
	{
		if (animator)
		{
			animator->animation->applyToSprite(sprite->sprite);
		}

		sf::Transformable t;
		t.setPosition(position->getGlobalPosition());

		window.draw(sprite->sprite, t.getTransform());
	}

	if (particle)
	{
		particle->particle_system->draw(window);
	}

	if (text)
	{
		sf::Transformable t;
		t.setPosition(position->getGlobalPosition());
		window.draw(text->text, t.getTransform());
	}
}
///

void RenderSystem::init()
{
}

void RenderSystem::update(const float &dt)
{
	auto _entitys = getEntitys();

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			auto position = entity.lock()->getComponent<PositionComponent>();

			auto particle = entity.lock()->getComponent<ParticleSystemComponent>();

			auto animator = entity.lock()->getComponent<AnimatorComponent>();

			if (particle)
			{
				particle->particle_system->setPositionEmitter(Math::Vector2(position->getGlobalPosition().x, position->getGlobalPosition().y));
				particle->particle_system->update(dt);
			}

			if (animator)
			{
				animator->animation->update(dt);
			}
		}
	}
}

void RenderSystem::draw(sf::RenderWindow &window)
{
	auto _entitys = getEntitys();

	std::sort(_entitys.begin(), _entitys.end(), [&](std::weak_ptr<Ecs::Entity> &entity1, std::weak_ptr<Ecs::Entity> &entity2) {
		return entity1.lock()->getComponent<LayerComponent>()->layer < entity2.lock()->getComponent<LayerComponent>()->layer;
	});

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			drawComponents(entity.lock().get(), window);
		}
	}
}

void MovementSystem::init()
{
}

void MovementSystem::update(const float &dt)
{
	auto _entitys = getEntitys();

	for (auto &entity : _entitys)
	{
		if (!entity.expired())
		{
			auto position = entity.lock()->getComponent<PositionComponent>();

			auto velocity = entity.lock()->getComponent<VelocityComponent>();

			position->position.x += velocity->velocity.x * dt;
			position->position.y += velocity->velocity.y * dt;
		}
	}
}

void CollisionSystem::init()
{
}

void CollisionSystem::update(const float &dt)
{
	auto _entitys = getEntitys();

	for (auto &entityi : _entitys)
	{
		for (auto &entityj : _entitys)
		{
			if (!entityi.expired() && !entityj.expired())
			{
				if (entityi.lock() != entityj.lock())
				{
					auto aabb1 = entityi.lock()->getComponent<AABBComponent>();

					auto pos1 = entityi.lock()->getComponent<PositionComponent>();
					aabb1->setPosition(pos1->getGlobalPosition());

					auto aabb2 = entityj.lock()->getComponent<AABBComponent>();
					auto pos2 = entityj.lock()->getComponent<PositionComponent>();

					aabb2->setPosition(pos2->getGlobalPosition());

					if (aabb1->aabb.intersects(aabb2->aabb))
					{
						aabb1->callible(entityi.lock().get(), entityj.lock().get());
					}
				}
			}
		}
	}
}