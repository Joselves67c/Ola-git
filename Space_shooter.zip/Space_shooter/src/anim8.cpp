#include "anim8.hpp"

Animation::Animation(sf::Texture &texture, int frameWidth, int frameHeight, int columns, int rows, float frameDuration)
	: m_texture(texture), m_frameWidth(frameWidth), m_frameHeight(frameHeight), m_columns(columns), m_rows(rows), m_frameDuration(frameDuration), m_currentFrame(0), m_elapsedTime(0.0f)
{
	for (int y = 0; y < rows; ++y)
	{
		for (int x = 0; x < columns; ++x)
		{
			sf::IntRect frame(x * frameWidth, y * frameHeight, frameWidth, frameHeight);
			m_frames.push_back(frame);
		}
	}
}

void Animation::update(float deltaTime)
{
	m_elapsedTime += deltaTime;
	if (m_elapsedTime >= m_frameDuration)
	{
		m_elapsedTime = 0.0f;
		m_currentFrame = (m_currentFrame + 1) % m_frames.size();
	}
}

void Animation::applyToSprite(sf::Sprite &sprite)
{
	sprite.setTexture(m_texture);
	sprite.setTextureRect(m_frames[m_currentFrame]);
}

const int &Animation::getCurrentFrame() const
{
	return m_currentFrame;
}