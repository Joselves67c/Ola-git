#include "game_states.hpp"
#include "wvector2.hpp"
#include "player_spawne.hpp"
#include "enemy_spawner.hpp"
#include "end_game_system.hpp"
#include "game_scenes.hpp"


void MainMenu::init()
{
	Button start;
	start.setPosition(WVector2(0, 268).getSfmlVector());
	
	start.setSize(WVector2(265, 85).getSfmlVector());
	start.setShowRectangle(false);
	start.setCall([&]() {
		auto level1 = m_scenes->getScene<Level1>("Level1");

		if (!level1)
		{
			level1 = m_scenes->addScene<Level1>("Level1");

			m_scenes->loadScene("Level1");
		}
	});
	
	Button  options;
	
	options.setPosition(WVector2(0, 410).getSfmlVector());
	options.setSize(WVector2(280,83).getSfmlVector());
	options.setShowRectangle(false);
	options.setCall([&]() {
		
		auto scene_options=m_scenes->addScene<Options>("Options");
		
		scene_options->music=&music;
		scene_options->background.setTexture(m_textures.get("BackGround"));
		scene_options->background.setScale(WVector2::toWorldScreen(1,1).getSfmlVector());
		
		m_scenes->loadScene("Options");
	});
	
	//550 280 75
	Button author;
	
	author.setPosition(WVector2(0,550).getSfmlVector());
	author.setSize(WVector2(280, 75).getSfmlVector());
	author.setShowRectangle(false);
	author.setCall([&]() {
		m_scenes->loadScene("Author");
	});
	
	Button b_exit;
	
	b_exit.setPosition(WVector2(0, 700).getSfmlVector());
	b_exit.setSize(WVector2(195, 65).getSfmlVector());
	b_exit.setShowRectangle(false);
	b_exit.setCall([&]() {
		window->close();
	});
	
	
	buttons.push_back(start);
	buttons.push_back(options);
	buttons.push_back(author);
	buttons.push_back(b_exit);

	std::string path = "./assets/";

	m_textures.load("Nave", path + "Nave.png");
	m_textures.load("Enemy", path + "Enemy.png");
	m_textures.load("BulletPlayer",path+"Bullet2.png");
	m_textures.load("BulletEnemy",path+"Bullet1.png");
	m_textures.load("Emmo",path+"Emmo.png");
	m_textures.load("Health",path+"Health.png");
	m_textures.load("NaveExplode",path+"NaveExplosion.png");
	m_textures.load("BulletExplode",path+"explosion.png");
	
	m_textures.load("BackGround",path+"Stars-A.png");
	m_textures.load("Menu",path+"Menu.png");
	m_textures.load("PauseIcon",path+"pause_icon.png");
	
	m_sounds.load("BulletShoot",path+"laser_shoot7.wav");
	m_sounds.load("BulletExplosion",path+"beam6.wav");
	m_sounds.load("EnemyExplosion",path+"explosion12.wav");
	m_sounds.load("BulletEnemyShoot",path+"soundwave_shoot.wav");
	m_sounds.load("SoundPacks",path+"eff3.wav");
	m_sounds.load("NaveSoundExplode",path+"explosion7.wav");
	
	if(!music.openFromFile(path+"ShortMelody.wav"))
	{
		throw std::runtime_error("musica");
	}
	
	
	music.setLoop(true);
	
	music.play();
	
	menu_sprite.setTexture(m_textures.get("Menu"));
	menu_sprite.setScale(WVector2::toWorldScreen(1,1).getSfmlVector());
	
	
	
}

void MainMenu::events(sf::Event &e)
{
	for (auto &button : buttons)
	{
		button.event(e);
	}
}

void MainMenu::update(const float &)
{
}

void MainMenu::render(sf::RenderWindow &window)
{
	for (auto &button : buttons)
	{
		button.draw(window);
		
	}
	
	window.draw(menu_sprite);
}

///nivel 1

void Level1::init()
{
	auto main_menu = m_scenes->getScene<MainMenu>("MainMenu");

	auto player_spawner=world.addSystem<PlayerSpawner>();
	
	player_spawner->m_textures=&main_menu->m_textures;
	player_spawner->m_sounds=&main_menu->m_sounds;
	
	world.addSystem<ResurceDestroy>();
	world.addSystem<NaveHealthSystem>();
   world.addSystem<InputSystem>();
   world.addSystem<EnemySpawne>()->m_textures=&main_menu->m_textures;
   world.addSystem<AiDecisionSystem>();
   world.addSystem<BulletSystem>();
   world.addSystem<EndGameSystem>()->m_scenes=m_scenes;
	world.addSystem<MovementSystem>();
	world.addSystem<CollisionSystem>();
	world.addSystem<RenderSystem>();

	world.init();
	
	pause_icon.setTexture(main_menu->m_textures.get("PauseIcon"));
	
	pause_icon.setPosition(WVector2(542,30).toWorldScreen().getSfmlVector());
	
	pause_icon.setScale(WVector2::toWorldScreen(1,1).getSfmlVector());
	
	pause.setPosition(WVector2(542,30).getSfmlVector());
	pause.setSize(WVector2(40,40).getSfmlVector());
	
	pause.setShowRectangle(false);
	
	pause.setCall([&](){
		
		m_scenes->loadScene("Pause");
		
	});
}

void Level1::events(sf::Event &e)
{
	  pause.event(e);
	world.getSystem<InputSystem>()->events(e);
	
}

void Level1::update(const float &dt)
{
	world.update(dt);
	
}

void Level1::render(sf::RenderWindow &window)
{
	world.getSystem<RenderSystem>()->draw(window);
	pause.draw(window);
	window.draw(pause_icon);
}