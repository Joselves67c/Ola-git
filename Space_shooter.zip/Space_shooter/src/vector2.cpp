#include "vector2.hpp"
#include <iostream>

namespace Math
{
	//construtor da classe Vector
	Vector2::Vector2(const Real& _x,const Real& _y):x(_x),y(_y){}
	
	//funcao que realiza adicao de vetores
	Vector2 Vector2::operator+(const Vector2& v)const
	{
		return Vector2(this->x+v.x,this->y+v.y);
	}
	
	//
	void Vector2::operator+=(const Vector2& v)
	{
		*this=*this+v;
	}
	
	//funcao que realiza subtracao de vetores
	Vector2 Vector2::operator-(const Vector2& v)const
	{
		return Vector2(this->x-v.x,this->y-v.y);
	}
	
	//
	void Vector2::operator-=(const Vector2& v)
	{
		*this=*this-v;
	}
	
	//funcao que multiplica o vetor um escalar
	Vector2 Vector2::operator*(const Real& s)const
	{
		return Vector2(this->x*s,this->y*s);
	}
	
	//
	void Vector2::operator*=(const Real& s)
	{
		*this=*this*s;
	}
	
	//funçao que realiza o produto escalar
	Real Vector2::operator*(const Vector2& v)const
	{
		return this->x*v.x+this->y*v.y;
	}
	
	//funcao que retorna o tamanho do vetor
	Real Vector2::magnitude()const
	{
		return real_sqrt(*this**this);
	}
	
	//funçao que retorna esse vetor como unitario
	Vector2 Vector2::getUnity()const
	{
		Real m=this->magnitude();
		
		if(m>0)
		{
			Vector2 v=*this;
			
			v*=(1/m);
			
			return v;
		}
		return *this;
	}
	
	//normaliza este vetor
	void Vector2::normalize()
	{
		*this=this->getUnity();
	}
	
	//retorna um vetor perpendicular
	Vector2 Vector2::getPerpendicular()const
	{
		return Vector2(-this->y,this->x);
	}
	
	//inverte este vetor
	void Vector2::invert()
	{
		*this=*this*-1;
	}
	
	std::ostream& operator<<(std::ostream& out,const Math::Vector2& v)
{
	out<<"["<<v.x<<" "<<v.y<<"]";
	
	return out;
}
}

